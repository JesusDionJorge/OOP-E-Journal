
//Find out factorial of a number.

public class FactDemo {
	
	
	public static void main(String [] args){
				
		Factorial f;		
		
		f = new Factorial();	
		
		f.findFactorial();
			
		
	}
	

}

