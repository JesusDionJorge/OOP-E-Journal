
public class StudentDemo {

	public static void main(String[] args) {
		
		Student stud = new Student();
		stud.setStudentInfo();			
		stud.displayStudentInfo();
		
		stud.setName("Abhishek");		
		System.out.println("Student's Name: " + stud.getName()); 
		
		
		
		
	}

}
