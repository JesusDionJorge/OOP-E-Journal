
//Generate Fibonacci series till a given number.
public class FibonacciDemo {
	
public static void main(String[] args) {
		
		Fibonacci f;
		
		f = new Fibonacci();
		
		f.showFibonacci();

	}
}
