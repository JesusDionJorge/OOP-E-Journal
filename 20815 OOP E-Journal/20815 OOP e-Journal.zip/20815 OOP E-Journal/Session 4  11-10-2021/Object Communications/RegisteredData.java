
public class RegisteredData {
	private Student stud;		
	private Course cs;
	private String registrationNumber;
	private String registrationDate;
	
	public RegisteredData(){
		
	}
		
	public Student getStud() {
		return stud;
	}
	public void setStud(Student stud) {
		this.stud = stud;
	}
	public Course getCs() {
		return cs;
	}
	public void setCs(Course cs) {
		this.cs = cs;
	}
	public String getRegistrationNumber() {
		return registrationNumber;
	}
	public void setRegistrationNumber(String registrationNumber) {
		this.registrationNumber = registrationNumber;
	}
	public String getRegistrationDate() {
		return registrationDate;
	}
	public void setRegistrationDate(String registrationDate) {
		this.registrationDate = registrationDate;
	}
	
	
	

}
