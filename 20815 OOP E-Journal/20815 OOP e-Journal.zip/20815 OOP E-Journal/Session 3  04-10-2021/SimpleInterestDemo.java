
//Find out simple interest when principle, rate and rate of interest are known.
public class SimpleInterestDemo {
	public static void main(String[] args) {
		SimpleInterest s;
		
		s = new SimpleInterest();
		
		s.calculateSimpleInterest();
	}


}
