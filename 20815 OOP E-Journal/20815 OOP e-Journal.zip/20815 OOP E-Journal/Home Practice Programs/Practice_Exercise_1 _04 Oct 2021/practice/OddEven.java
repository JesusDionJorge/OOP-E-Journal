package practice;
//8.Find whether the number given is odd or even.
public class OddEven {

	public static void main(String[] args) {
		int num = 57;
		
        if (num % 2 == 0) {
 
            System.out.println(num+" is Even");
        }
 
        else {
 
            System.out.println(num+" is Odd");
        }
	}

}
