package oop_practice;
//13.Find out maximum of 3 numbers.
public class MaximumDemo {
	public static void main(String[] args) {
		MaximumOfThree m;
		
		m = new MaximumOfThree();
		
		m.findMaximumOfThree();
	}

}
