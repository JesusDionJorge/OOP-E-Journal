
public class CalculatorUser {

	
	public static void main(String[] args) {
		Calculator cal = new Calculator();
		
		System.out.println(cal.square(4.3));

	}

}
