
//Find out simple interest when principle, rate and rate of interest are known.
public class SimpleInterest {

	public static void main(String[] args) {
		float p= 40000,r= 16,t= 8,si;  
         
         si  = (p*r*t)/100;   
        System.out.println("Simple Interest is "+si);
	}

}
