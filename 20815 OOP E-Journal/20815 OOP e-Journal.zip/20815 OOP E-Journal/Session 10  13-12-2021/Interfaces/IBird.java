package interfaceExample;

public interface IBird {
	
	public abstract void eat();
}

