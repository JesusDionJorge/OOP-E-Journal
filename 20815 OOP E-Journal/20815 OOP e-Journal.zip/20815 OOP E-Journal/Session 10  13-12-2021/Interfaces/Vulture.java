package interfaceExample;

public class Vulture implements IBird {

	public void eat() {
		System.out.println("Vulture eats flesh"); 
	} 
}
