package practice;
//6.Find out area and perimeter of a rectangle
public class Rectangle {

	public static void main(String[] args) {
		int l ,b,area, perimeter;  
        l=14;  
        b=28;
        area=l*b;
        perimeter  = 2*(l+b);  
System.out.println("Area of the rectangle is "+area);
System.out.println("Perimeter of the rectangle is "+perimeter);
	}

}
