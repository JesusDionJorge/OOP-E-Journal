package interfaceExample;

public interface ICalculator {
	
	//Interface has abstract methods
	
	public abstract void add(int a, int b);
	public abstract void difference(int a, int b);
	public abstract void product(int a, int b);

}
