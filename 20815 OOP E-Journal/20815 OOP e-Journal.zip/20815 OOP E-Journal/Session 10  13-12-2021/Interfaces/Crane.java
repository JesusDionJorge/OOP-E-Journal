package interfaceExample;

public class Crane implements IBird {
	public void eat() {
		System.out.println("Crane eats fish"); 
	} 
}
