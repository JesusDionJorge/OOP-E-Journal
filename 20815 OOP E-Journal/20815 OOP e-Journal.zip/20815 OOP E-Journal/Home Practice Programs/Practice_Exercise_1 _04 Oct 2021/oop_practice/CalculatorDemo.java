package oop_practice;
//18.Calculator class to find out addition, subtraction, division, multiplication, and remainder of given numbers.
public class CalculatorDemo
{
    public static void main(String[]args)
    {

        Calculator a;
        a = new Calculator();
        a.findAdd();

        a.findSub();
 
        a.findMulti();

        a.findDiv();
        
        a.findRem();
       

    }
}
