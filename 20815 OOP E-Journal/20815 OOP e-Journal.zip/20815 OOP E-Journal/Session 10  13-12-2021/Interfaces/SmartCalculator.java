package interfaceExample;

public class SmartCalculator implements ICalculator{

	public void add(int a, int b) {
		
		
	}

	public void difference(int a, int b) {
		
		
	}

	public void product(int a, int b) {
		
		
	}

}
