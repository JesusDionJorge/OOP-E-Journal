package oop_practice;
//20.Create a Car Class with attributes and behaviors that you feel that it should be there.
public class CarDemo {

	public static void main(String[] args) {
		Car c = new Car();
		c.display();
		c.start();
		c.accelerate();
		c.accelerate();
		c.stop();
		c.deaccelerate();

	}

}