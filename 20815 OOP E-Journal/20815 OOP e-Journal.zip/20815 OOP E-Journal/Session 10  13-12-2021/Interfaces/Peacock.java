package interfaceExample;

public class Peacock implements IBird {
	public void eat(){
		System.out.println("Peacock eats grains"); 
	}
}
