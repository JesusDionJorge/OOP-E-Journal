//Add 2 numbers
public class Addition {

	public static void main(String[] args) {
		int a= 12;
		int b=8;
		int c;
		c= a + b;
		
		System.out.println("Sum of these two numbers is "+c);

	}

}
