
public class ArrayExample {

	public static void main(String[] args) {
		
		int arr1 [];
		arr1 = new int [5];  
		
		arr1[0]=2;
		arr1[1]=5;
		arr1[2]=-3;
		arr1[3]= 12;
		arr1[4]=-52;
		
		for (int i =0; i< 5; i++){
			System.out.print("["+ arr1[i]+ "] ");
		}
		
		int arr3 [] = new int [5];
		
		int arr2 [] ={2,3,5};
		
		
		
		
	}

}
