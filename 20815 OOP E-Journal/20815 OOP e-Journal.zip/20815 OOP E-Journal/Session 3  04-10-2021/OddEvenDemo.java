
//Find whether the number given is odd or even.
public class OddEvenDemo {
	public static void main(String[] args) {
		OddEven n;
		
		n = new OddEven();
		
		n.findOddEven();

	}

}
