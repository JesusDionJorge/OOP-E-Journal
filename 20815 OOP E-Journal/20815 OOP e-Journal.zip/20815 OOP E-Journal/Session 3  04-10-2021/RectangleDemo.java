
//Find out area and perimeter of a rectangle when length and breadth is known.

public class RectangleDemo {
	
	
	public static void main(String [] args){
		
		Rectangle rect;
		
		rect = new Rectangle();
		
		rect.findArea();
		rect.findPerimeter();
		
	}

}
