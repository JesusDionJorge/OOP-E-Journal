package oop_practice;
//19.Class to find total marks obtained and percentage when marks of any 5 subjects are given. Consider 100 to be maximum marks of each subject
public class MarksDemo {
	
	
    public static void main(String[] args) {
		
		Marks m = new Marks();
		m.getmarks();
		m.setmarks();

	}


}
